# TuxMathScrabble

A Math Game written in Python

<img src="tuxmathscrabble.png"/>

<img src="TuxMathScrabble-0.8.0.png"/>
